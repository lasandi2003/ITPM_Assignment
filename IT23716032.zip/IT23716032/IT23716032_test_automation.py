
from playwright.sync_api import sync_playwright
import time
import os
import argparse
import re
import glob
from pathlib import Path
import sys
import openpyxl
from openpyxl.cell.cell import MergedCell


SCRIPT_VERSION = "SAFE_V7_RETRY_PIXELSUITE_TEXTAREA"

ROOT_DIR = Path(__file__).resolve().parent
DEFAULT_FRONTEND_URL = os.getenv("FRONTEND_URL", "https://www.pixelssuite.com/chat-translator")

DEFAULT_EXCEL_CANDIDATES = [
    str(ROOT_DIR / "Assignment 1 - Test cases.xlsx"),
    str(ROOT_DIR / "IT23716032_Test cases.xlsx"),
    str(ROOT_DIR / "IT23716032_ Test cases.xlsx"),
    str(ROOT_DIR / "IT23716032-Test cases.xlsx"),
]

DEFAULT_SHEET_NAME = " Test cases"

DEFAULT_INPUT_COLUMN_CANDIDATES = [
    "Singlish", "Input", "Singlish Input", "Test Input", "Source", "Sentence", "Text",
]

DEFAULT_EXPECTED_COLUMN_CANDIDATES = [
    "Sinhala", "Expected_Output", "Expected Output", "Expected output",
    "Expected", "Expected Sinhala",
]

DEFAULT_ACTUAL_COLUMN_CANDIDATES = [
    "Actual_Output", "Actual Output", "Actual output", "Actual",
]

DEFAULT_STATUS_COLUMN_CANDIDATES = [
    "Status", "Result", "Pass/Fail", "Pass Fail",
]

DEFAULT_WAIT_MS = 15000
DEFAULT_RETRIES = 10
DEFAULT_RETRY_WAIT_MS = 2000
DEFAULT_TYPE_DELAY_MS = 80
DEFAULT_TIMEOUT_MS = 120000
DEFAULT_SLOW_MO_MS = 300


def _configure_stdout():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
    except Exception:
        pass


def _pick_existing_path(candidates):
    for p in candidates:
        if p and os.path.exists(p):
            return p
    return candidates[0] if candidates else None


def _resolve_path(p: str | None) -> str | None:
    if not p:
        return None

    p = str(p).strip().strip('"')

    if "*" in p or "?" in p:
        matches = glob.glob(p)
        if not matches:
            matches = glob.glob(str(ROOT_DIR / p))
        if matches:
            return str(Path(matches[0]).resolve())

    path = Path(p)

    if path.is_absolute():
        return str(path)

    folder_candidate = (ROOT_DIR / path).resolve()
    if folder_candidate.exists():
        return str(folder_candidate)

    return str(folder_candidate)


def _normalize_header(value) -> str:
    if value is None:
        return ""
    return re.sub(r"[^a-z0-9]+", "", str(value).strip().lower())


def _header_values(ws, row_index: int) -> list:
    max_col = max(1, int(ws.max_column or 1))
    return [ws.cell(row=row_index, column=c).value for c in range(1, max_col + 1)]


def _find_header_row(ws, max_scan_rows: int) -> int:
    input_tokens = {_normalize_header(v) for v in DEFAULT_INPUT_COLUMN_CANDIDATES}
    expected_tokens = {_normalize_header(v) for v in DEFAULT_EXPECTED_COLUMN_CANDIDATES}
    actual_tokens = {_normalize_header(v) for v in DEFAULT_ACTUAL_COLUMN_CANDIDATES}
    status_tokens = {_normalize_header(v) for v in DEFAULT_STATUS_COLUMN_CANDIDATES}

    best_score = -1
    best_row = 1
    scan_limit = max(1, min(int(max_scan_rows), int(ws.max_row or 1)))

    for r in range(1, scan_limit + 1):
        values = _header_values(ws, r)
        texts = [v for v in values if isinstance(v, str) and v.strip() and len(v.strip()) <= 80]

        if len(texts) < 2:
            continue

        norms = {_normalize_header(v) for v in texts}

        if "tcid" in norms and "input" in norms and "expectedoutput" in norms:
            return r

        if "input" not in norms:
            continue

        if not (norms & expected_tokens):
            continue

        score = 0
        for v in texts:
            n = _normalize_header(v)
            if n in input_tokens:
                score += 3
            if n in expected_tokens:
                score += 2
            if n in actual_tokens:
                score += 1
            if n in status_tokens:
                score += 1

        if score > best_score:
            best_score = score
            best_row = r

    return best_row


def _merged_top_left_cell(ws, row: int, col: int):
    cell = ws.cell(row=row, column=col)

    if not isinstance(cell, MergedCell):
        return cell

    for rng in ws.merged_cells.ranges:
        if rng.min_row <= row <= rng.max_row and rng.min_col <= col <= rng.max_col:
            return ws.cell(row=rng.min_row, column=rng.min_col)

    return ws.cell(row=row, column=col)


def _is_top_left_of_merged_cell(ws, row: int, col: int) -> bool:
    cell = ws.cell(row=row, column=col)

    if not isinstance(cell, MergedCell):
        return True

    for rng in ws.merged_cells.ranges:
        if rng.min_row <= row <= rng.max_row and rng.min_col <= col <= rng.max_col:
            return rng.min_row == row and rng.min_col == col

    return True


def _set_cell_value(ws, row: int, col: int, value):
    cell = _merged_top_left_cell(ws, row, col)
    cell.value = value


def _find_column_index(header_values: list, requested_name: str | None, candidates: list[str]) -> int | None:
    indexed = []

    for i, v in enumerate(header_values, start=1):
        if v is None:
            continue
        indexed.append((i, str(v)))

    norm_to_index: dict[str, int] = {}

    for i, v in indexed:
        n = _normalize_header(v)
        if n and n not in norm_to_index:
            norm_to_index[n] = i

    def match(name: str) -> int | None:
        n = _normalize_header(name)

        if not n:
            return None

        if n in norm_to_index:
            return norm_to_index[n]

        for i, v in indexed:
            hv = _normalize_header(v)
            if n in hv or hv in n:
                return i

        return None

    if requested_name:
        found = match(requested_name)
        if found:
            return found

    for c in candidates:
        found = match(c)
        if found:
            return found

    return None


def _last_header_col(header_values: list) -> int:
    last = 0

    for i, v in enumerate(header_values, start=1):
        if v is None:
            continue
        if isinstance(v, str) and not v.strip():
            continue
        last = i

    return last


def _ensure_column(ws, header_row: int, header_values: list, desired_name: str) -> int:
    found = _find_column_index(header_values, desired_name, [])

    if found:
        return found

    col = _last_header_col(header_values) + 1
    ws.cell(row=header_row, column=col).value = desired_name

    if col <= len(header_values):
        header_values[col - 1] = desired_name
    else:
        while len(header_values) < col - 1:
            header_values.append(None)
        header_values.append(desired_name)

    return col


def _dismiss_overlays(page):
    candidates = [
        ("button", re.compile(r"^(Accept|I Agree|Agree|OK|Got it)$", re.IGNORECASE)),
        ("button", re.compile(r"^(Accept all|Accept All)$", re.IGNORECASE)),
        ("button", re.compile(r"^(Close|No thanks|Not now)$", re.IGNORECASE)),
    ]

    for role, name in candidates:
        try:
            btn = page.get_by_role(role, name=name).first
            if btn.is_visible(timeout=1000):
                btn.click(timeout=2000)
                page.wait_for_timeout(500)
        except Exception:
            pass


def _install_redirect_protection(page):
    def handle_route(route, request):
        try:
            url = request.url.lower()

            blocked_keywords = [
                "frs2c.com", "mks98.com", "hotcoin.com", "doubleclick",
                "googlesyndication", "adservice", "popads", "adsterra",
                "onclick", "push",
            ]

            if any(x in url for x in blocked_keywords):
                print(f"Blocked redirect/ad request: {request.url}")
                route.abort()
                return

            route.continue_()

        except Exception:
            try:
                route.continue_()
            except Exception:
                pass

    try:
        page.route("**/*", handle_route)
    except Exception:
        pass


def _try_load_pixelsuite(page, url: str, timeout_ms: int) -> bool:
    for attempt in range(1, 9):
        print(f"PixelSuite open attempt {attempt}/8")

        try:
            page.goto("about:blank", wait_until="domcontentloaded", timeout=10000)
        except Exception:
            pass

        try:
            page.goto(url, wait_until="domcontentloaded", timeout=max(1000, int(timeout_ms)))
        except Exception as e:
            print(f"Open attempt {attempt} warning: {e}")

        # Quick checking for translator before ad redirect happens
        for _ in range(1, 11):
            try:
                current = page.url.lower()

                if "google.com" in current:
                    print(f"Wrong page opened: {page.url}. Retrying...")
                    break

                if "chrome-error://chromewebdata" in current:
                    print("Chrome error page after blocked redirect. Retrying...")
                    break

                if "pixelssuite.com" in current:
                    try:
                        textarea_count = page.locator("textarea").count()
                        if textarea_count >= 2:
                            try:
                                page.evaluate("window.stop()")
                            except Exception:
                                pass
                            print("Frontend loaded successfully.")
                            return True
                    except Exception:
                        pass

                page.wait_for_timeout(1000)

            except Exception as e:
                print(f"Load check warning: {e}")
                break

        print(f"Current page after attempt {attempt}: {page.url}")

    return False


def _clear_textarea(page, locator, attempts: int = 3):
    for _ in range(max(1, int(attempts))):
        try:
            locator.click(timeout=3000)
        except Exception:
            pass

        try:
            page.keyboard.press("Control+A")
            page.keyboard.press("Backspace")
        except Exception:
            pass

        try:
            locator.fill("")
        except Exception:
            pass

        try:
            locator.evaluate(
                """(el) => {
                    if ('value' in el) {
                        el.value = '';
                        el.dispatchEvent(new Event('input', { bubbles: true }));
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }"""
            )
        except Exception:
            pass

        try:
            if locator.input_value() == "":
                return
        except Exception:
            pass

        page.wait_for_timeout(200)


def _ensure_input_value(page, input_locator, text: str, type_delay_ms: int):
    _clear_textarea(page, input_locator)

    try:
        input_locator.click(timeout=5000)
    except Exception:
        pass

    if type_delay_ms and int(type_delay_ms) > 0:
        try:
            input_locator.type(text, delay=int(type_delay_ms))
        except Exception:
            input_locator.fill(text)
    else:
        input_locator.fill(text)

    try:
        current = input_locator.input_value()
        if current is not None and str(current).strip() == text.strip():
            return
    except Exception:
        pass

    page.wait_for_timeout(300)
    _clear_textarea(page, input_locator)

    try:
        input_locator.fill(text)
    except Exception:
        pass


def _read_output(output_locator) -> str:
    methods = [
        lambda: output_locator.input_value(timeout=3000),
        lambda: output_locator.text_content(timeout=3000),
        lambda: output_locator.inner_text(timeout=3000),
        lambda: output_locator.evaluate("(el) => el && ('value' in el ? el.value : (el.innerText || el.textContent || ''))"),
    ]

    for method in methods:
        try:
            v = method()
            if v is not None:
                v = str(v).strip()
                if v:
                    return v
        except Exception:
            pass

    return ""


def _find_transliterate_button(page):
    button_candidates = [
        page.get_by_role("button", name=re.compile(r"Transliterate", re.IGNORECASE)).first,
        page.locator("button").filter(has_text=re.compile(r"Transliterate", re.IGNORECASE)).first,
    ]

    for btn in button_candidates:
        try:
            if btn.count() > 0 and btn.is_visible(timeout=2000):
                return btn
        except Exception:
            pass

    return None


def _find_chat_locators(page, timeout_ms: int):
    deadline = time.time() + (max(1, timeout_ms) / 1000)
    last_debug = None

    while time.time() < deadline:
        _dismiss_overlays(page)

        current_url = page.url.lower()

        if "google.com" in current_url:
            raise RuntimeError(f"Wrong page opened: {page.url}. Stopped to avoid Google search typing.")

        if "pixelssuite.com" not in current_url:
            raise RuntimeError(f"Page changed away from PixelSuite: {page.url}")

        try:
            all_textareas = page.locator("textarea")
            count = all_textareas.count()
            visible_textareas = []

            for i in range(count):
                loc = all_textareas.nth(i)
                try:
                    box = loc.bounding_box(timeout=1000)
                    if box and box.get("width", 0) > 80 and box.get("height", 0) > 50:
                        visible_textareas.append(loc)
                except Exception:
                    try:
                        if loc.is_visible(timeout=1000):
                            visible_textareas.append(loc)
                    except Exception:
                        pass

            if len(visible_textareas) >= 2:
                action = _find_transliterate_button(page)
                return visible_textareas[0], visible_textareas[1], action

        except Exception as e:
            last_debug = str(e)

        page.wait_for_timeout(500)

    try:
        meta = page.evaluate(
            """() => Array.from(document.querySelectorAll('textarea')).map((t, index) => ({
                index,
                placeholder: t.getAttribute('placeholder') || '',
                disabled: !!t.disabled,
                readOnly: !!t.readOnly,
                value: t.value || '',
                visible: !!(t.offsetParent),
                width: t.getBoundingClientRect().width,
                height: t.getBoundingClientRect().height
            }))"""
        )
        print("Debug: textarea meta:", meta)
    except Exception as e:
        print("Debug: failed to read textarea meta:", e)

    if last_debug:
        print("Debug: last locator error:", last_debug)

    raise RuntimeError("Could not find PixelSuite input/output textareas.")


def _parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--excel", default=_pick_existing_path(DEFAULT_EXCEL_CANDIDATES))
    parser.add_argument("--sheet", default=DEFAULT_SHEET_NAME)
    parser.add_argument("--header-row", type=int, default=0)
    parser.add_argument("--max-header-scan-rows", type=int, default=30)
    parser.add_argument("--input-col", default=None)
    parser.add_argument("--expected-col", default=None)
    parser.add_argument("--actual-col", default=None)
    parser.add_argument("--status-col", default=None)
    parser.add_argument("--url", default=DEFAULT_FRONTEND_URL)
    parser.add_argument("--output", default=None)
    parser.add_argument("--save-every", type=int, default=1)
    parser.add_argument("--headless", action="store_true", default=False)
    parser.add_argument("--wait-ms", type=int, default=DEFAULT_WAIT_MS)
    parser.add_argument("--retries", type=int, default=DEFAULT_RETRIES)
    parser.add_argument("--retry-wait-ms", type=int, default=DEFAULT_RETRY_WAIT_MS)
    parser.add_argument("--type-delay-ms", type=int, default=DEFAULT_TYPE_DELAY_MS)
    parser.add_argument("--timeout-ms", type=int, default=DEFAULT_TIMEOUT_MS)
    parser.add_argument("--slow-mo-ms", type=int, default=DEFAULT_SLOW_MO_MS)
    parser.add_argument("--keep-open", action="store_true", default=False)

    return parser.parse_args()


def run_test():
    _configure_stdout()
    args = _parse_args()

    print(f"Script version: {SCRIPT_VERSION}")

    args.excel = _resolve_path(args.excel)
    args.output = _resolve_path(args.output) if args.output else args.excel

    if not args.excel or not os.path.exists(args.excel):
        print(f"Error: File '{args.excel}' not found.")
        print("Tip: Check Excel file name or use --excel *.xlsx")
        return

    try:
        wb = openpyxl.load_workbook(args.excel)
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        print("Tip: Close the Excel file and run again.")
        return

    if args.sheet and args.sheet in wb.sheetnames:
        ws = wb[args.sheet]
    else:
        ws = wb.active

    header_row = int(args.header_row or 0)

    if header_row <= 0:
        header_row = _find_header_row(ws, int(args.max_header_scan_rows))

    header_values = _header_values(ws, header_row)

    input_col_idx = _find_column_index(header_values, args.input_col, DEFAULT_INPUT_COLUMN_CANDIDATES)
    expected_col_idx = _find_column_index(header_values, args.expected_col, DEFAULT_EXPECTED_COLUMN_CANDIDATES)

    if not input_col_idx:
        printable = [str(v) if v is not None else "" for v in header_values]
        print("Error: Could not resolve input column.")
        print(f"Header row: {header_row}")
        print(f"Available columns: {printable}")
        return

    actual_col_name = args.actual_col or "Actual output"
    status_col_name = args.status_col or "Status"

    actual_col_idx = _find_column_index(header_values, args.actual_col, DEFAULT_ACTUAL_COLUMN_CANDIDATES)
    status_col_idx = _find_column_index(header_values, args.status_col, DEFAULT_STATUS_COLUMN_CANDIDATES)

    actual_col_idx = actual_col_idx or _ensure_column(ws, header_row, header_values, actual_col_name)
    status_col_idx = status_col_idx or _ensure_column(ws, header_row, header_values, status_col_name)

    test_rows = []

    for row_index in range(header_row + 1, int(ws.max_row or 0) + 1):
        if not _is_top_left_of_merged_cell(ws, row_index, input_col_idx):
            continue

        input_cell = _merged_top_left_cell(ws, row_index, input_col_idx)
        input_value = input_cell.value
        singlish_input = str(input_value).strip() if input_value is not None else ""

        if singlish_input:
            test_rows.append(row_index)

    print(f"Starting Frontend-Only test with {len(test_rows)} rows...")

    with sync_playwright() as p:
        if args.headless:
            print("Running in headless mode. Remove --headless to watch typing.")

        browser = p.chromium.launch(
            headless=args.headless,
            slow_mo=max(0, int(args.slow_mo_ms)),
            args=[
                "--disable-popup-blocking",
                "--disable-notifications",
                "--no-default-browser-check",
                "--disable-features=Translate",
            ],
        )

        context = browser.new_context()
        page = context.new_page()
        page.set_default_timeout(max(1000, int(args.timeout_ms)))

        _install_redirect_protection(page)

        print(f"Opening URL: {args.url}")

        if not _try_load_pixelsuite(page, args.url, int(args.timeout_ms)):
            print("Error: PixelSuite did not load correctly after several attempts.")
            print("Reason: Website is redirecting to ad pages before translator loads.")
            print("Try mobile hotspot/another network, then run again.")

            if args.keep_open and not args.headless:
                print("Keeping browser open for checking. Press CTRL+C in CMD to stop.")
                try:
                    while True:
                        page.wait_for_timeout(1000)
                except KeyboardInterrupt:
                    pass

            browser.close()
            return

        try:
            input_locator, output_locator, action_locator = _find_chat_locators(page, int(args.timeout_ms))
            print("PixelSuite input/output boxes located successfully.")
        except Exception as e:
            print(f"Error locating chat UI elements: {e}")

            if args.keep_open and not args.headless:
                print("Keeping browser open for checking. Press CTRL+C in CMD to stop.")
                try:
                    while True:
                        page.wait_for_timeout(1000)
                except KeyboardInterrupt:
                    pass

            browser.close()
            return

        processed = 0

        for row_index in test_rows:
            input_cell = _merged_top_left_cell(ws, row_index, input_col_idx)
            singlish_input = str(input_cell.value).strip() if input_cell.value is not None else ""

            expected_value = (
                _merged_top_left_cell(ws, row_index, expected_col_idx).value
                if expected_col_idx
                else None
            )
            expected_sinhala = str(expected_value).strip() if expected_value is not None else ""

            print(f"Testing [Row {row_index}]: {singlish_input}")

            try:
                if "google.com" in page.url.lower():
                    raise RuntimeError(f"Wrong page opened: {page.url}. Stopped to avoid Google search typing.")

                if "pixelssuite.com" not in page.url.lower():
                    raise RuntimeError(f"Page changed away from PixelSuite: {page.url}")

                _dismiss_overlays(page)

                previous_output = _read_output(output_locator)

                _ensure_input_value(page, input_locator, singlish_input, int(args.type_delay_ms))

                if action_locator:
                    try:
                        action_locator.click(timeout=5000)
                    except Exception:
                        pass

                page.wait_for_timeout(max(0, int(args.wait_ms)))

                actual_output = ""
                tries = max(1, int(args.retries))

                for _ in range(tries):
                    current_output = _read_output(output_locator)

                    if current_output and current_output != previous_output:
                        actual_output = current_output
                        break

                    if current_output and not previous_output:
                        actual_output = current_output
                        break

                    page.wait_for_timeout(max(0, int(args.retry_wait_ms)))

                _set_cell_value(ws, row_index, actual_col_idx, actual_output)

                if expected_sinhala:
                    status = "PASS" if actual_output == expected_sinhala else "FAIL"
                else:
                    status = "COLLECTED"

                _set_cell_value(ws, row_index, status_col_idx, status)

                print(f"  -> {status}")
                processed += 1

                if args.save_every and int(args.save_every) > 0:
                    if processed % int(args.save_every) == 0:
                        wb.save(args.output)

            except Exception as e:
                print(f"Error in UI interaction: {e}")

                try:
                    _set_cell_value(ws, row_index, status_col_idx, "UI Error")
                except Exception:
                    pass

                if args.save_every and int(args.save_every) > 0:
                    try:
                        wb.save(args.output)
                    except Exception:
                        pass

        try:
            wb.save(args.output)
        except Exception as e:
            print(f"Error saving output file '{args.output}': {e}")
            print("Tip: Close Excel and run again.")
            browser.close()
            return

        print(f"Test completed. Results saved to {args.output}")

        if args.keep_open and not args.headless:
            print("Keeping browser open. Press CTRL+C in CMD to stop.")
            try:
                while True:
                    page.wait_for_timeout(1000)
            except KeyboardInterrupt:
                try:
                    wb.save(args.output)
                except Exception:
                    pass

        browser.close()


if __name__ == "__main__":
    run_test()
